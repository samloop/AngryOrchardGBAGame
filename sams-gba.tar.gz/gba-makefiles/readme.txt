SAM LOOP
"ANGRY ORCHARD"
HW 9
CS 2110

Hi!

What I have prepared for you today (just kidding this took me a while and also skimmed some years off my life) is a game I call "Angry Orchard." Partly named after the beverage, partly named after the game concept itself, and partly named because at times making this game made me angry (in a CS way.) 

The objective of the game is for the player, as Drake, to collect apples.Unforunately, Drake got enemies, got a lotta enemies: you must also avoid some spooky pests (a bat and snake) whilst collecting apples. The game ends when Drizzy collides with either of these forest creatures. Give Drake the One Dance he needs with the following controls:

BUTTON				FUNCTION
START				start game
SELECT				return to title screen
LEFT				move left
RIGHT				move right
DOWN				duck (avoid bats)
UP				jumpman jumpman jumpman (avoid snakes)
A				press for surprise from drizzy


That's it. The real is on the rise. It has its flaws, but.... God's plan. 

-----end readme-----
