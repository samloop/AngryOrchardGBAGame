//Sam Loop
//CS 2110
//HW 9

#include <stdio.h>
#include "gbaImages.h"
#include "myLib.h"


#define REG_DISPCTL *(unsigned short *)0x4000000
#define MODE3 3

#define SCREENHEIGHT 149

#define BG2_ENABLE (1<<10)

extern const unsigned short titlescreen[38400];
extern const unsigned short gameover[38400];
extern const unsigned short downdrake[4080];
extern const unsigned short normdrake[4080];
extern const unsigned short updrake[4080];
extern const unsigned short bat[675];
extern const unsigned short apple[400];
extern const unsigned short snake[450];

int main() {
	REG_DISPCTL = MODE3 | BG2_ENABLE;

	int score = 0;
	char buffer[41];
	int start = 0;
	flying batty;
	batty.x = 90;
	batty.y = 240;
	slither snakey;
	snakey.x = 140;
	snakey.y = 0;

	//starts at titlescreen
	drawImage(0, 0, TITLESCREEN_WIDTH, TITLESCREEN_HEIGHT, titlescreen);
	sprintf(buffer, "Press START to play");
	drawString(50, 59, buffer, YELLOW);

	while(1) {
		fruit froot;
		drake player;

		if(KEY_DOWN_NOW(BUTTON_START)) {
			drawBlackRectangle(0, 0, 240, 160);
			player.x = 94;
			player.y = 95;
			player.boolIsUp = 0;
			player.boolIsDown = 0;
			drawImage(player.x, player.y, NORMDRAKE_WIDTH, NORMDRAKE_HEIGHT, normdrake);
			start = 1;
		}
		if(KEY_DOWN_NOW(BUTTON_SELECT)) {
			drawImage(0, 0, TITLESCREEN_WIDTH, TITLESCREEN_HEIGHT, titlescreen);
			score = 0;
			start = 0;
		}
		if (KEY_DOWN_NOW(BUTTON_LEFT)) {
			if ((&(player.y) != NULL)) {
				player.y = player.y - 15;
				if (start == 1) {
					//redraw stage
					drawBlackRectangle(player.x, player.y + UPDRAKE_WIDTH, 15, UPDRAKE_HEIGHT);
				}
			}
		}
		if (KEY_DOWN_NOW(BUTTON_RIGHT)) {
			if ((&(player.y) != NULL)) {
				player.y = player.y + 15;
				if (start == 1) {
					//redraw stage
					drawBlackRectangle(player.x, player.y - 15, 15, UPDRAKE_HEIGHT);
				}
			}
		}
		if (KEY_DOWN_NOW(BUTTON_UP)) {
			if (player.boolIsDown) {
				player.boolIsDown = 0;
			} else if (!(player.boolIsUp)) {
				player.boolIsUp = 1;
				player.x = player.x - 20;
				if (start == 1) {
					//redraw stage
					drawBlackRectangle(player.x + UPDRAKE_HEIGHT, player.y, UPDRAKE_WIDTH, 20);	
				}
			}
		}
		if (KEY_DOWN_NOW(BUTTON_DOWN)) {
			if (player.boolIsUp) {
				player.boolIsUp = 0;
				player.x = player.x + 20;
				if (start == 1) {
					//redraw stage
					drawBlackRectangle(player.x - 20, player.y, UPDRAKE_WIDTH, 20);
				}
			} else {
				player.boolIsDown = 1;
			}
		}
		//yolo
		if (KEY_DOWN_NOW(BUTTON_A)) {
			sprintf(buffer, "runnin thru the six with my woes");
			drawString(50, 50, buffer, YELLOW);
		}

		if (start == 1) {
			if (froot.x >= 150) { //bottom of screen
				//fruit collision
				if ((froot.x + APPLE_HEIGHT) >= player.x && froot.x <= (player.x + UPDRAKE_HEIGHT)) {
					if ((froot.y + APPLE_WIDTH) >= player.y && froot.y <= (player.y + UPDRAKE_WIDTH)) {
						score++;
						//redraw stage
						drawBlackRectangle(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT);
						froot.x = 10;
						froot.y = (((score + 11) * 7) % 3) * 23; //so they don't just fall left to right on screen
						drawImage(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT, apple);
					}
				} else {
					froot.y = (((score + 11) * 7) % 3) * 23;
					drawImage(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT, apple);
				}
				//redraw stage
				drawBlackRectangle(froot.x, froot.y, APPLE_WIDTH, 10);
				//draw froot
				froot.x = 10;
				drawImage(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT, apple);
			} else {
				//redraw stage
				drawBlackRectangle(froot.x, froot.y, APPLE_WIDTH, 2);
				//Yeezy falls
				froot.x += 2;
				//yeezy collision
				if ((froot.x + APPLE_HEIGHT) >= player.x && froot.x <= (player.x + UPDRAKE_HEIGHT)) {
					if ((froot.y + APPLE_WIDTH) >= player.y && froot.y <= (player.y + UPDRAKE_WIDTH)) {
						score++;
						//redraw stage
						drawBlackRectangle(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT);
						froot.x = 10;
						froot.y = (((score + 11) * 7) % 9) * 23; //so they don't just fall left to right on screen
						drawImage(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT, apple);
					}
				} else {
					drawImage(froot.x, froot.y, APPLE_WIDTH, APPLE_HEIGHT, apple);
				}
			}
		}
			

		//handle spawning and colliding bats
		if ((batty.y + 1) > 240) { //moves offsceen
			batty.y = 0;
		} else {
			batty.y = batty.y + 1; // moves
		}
		if ((batty.y + BAT_WIDTH) >= player.y) {								//collision code
			if (batty.y <= (player.y + NORMDRAKE_WIDTH)) {
				if (player.boolIsDown == 0) {
					if (start) {
						drawImage(0,0, GAMEOVER_WIDTH, GAMEOVER_HEIGHT, gameover);
						start = 0;
						batty.y = 240;
						sprintf(buffer, "Score: %d", score);
						drawString(100, 90, buffer, YELLOW);
					}
				}
			}
		}
		//handle spawning and colliding snakes
		if ((snakey.y - 1 < 0)) { //moves offsceen
			snakey.y = 240;
		} else {
			snakey.y = snakey.y - 1; // moves
		}
		if ((snakey.y + SNAKE_WIDTH) >= player.y) {								//collision code
			if (snakey.y <= (player.y + NORMDRAKE_WIDTH)) {
				if (player.boolIsUp == 0) {
					if (start) {
						drawImage(0,0, GAMEOVER_WIDTH, GAMEOVER_HEIGHT, gameover);
						start = 0;
						snakey.y = 0;
						sprintf(buffer, "Score: %d", score);
						drawString(100, 90, buffer, YELLOW);
					}
				}
			}
		}

		//drawing drake
		if (start == 1) {
			if (player.boolIsUp) {
				drawImage(player.x, player.y, UPDRAKE_WIDTH, UPDRAKE_HEIGHT, updrake);
			} else if (player.boolIsDown) {
				drawImage(player.x, player.y, DOWNDRAKE_WIDTH, DOWNDRAKE_HEIGHT, downdrake);
			} else {
				drawImage(player.x, player.y, NORMDRAKE_WIDTH, NORMDRAKE_HEIGHT, normdrake);
			}

		//snakes
		drawImage(snakey.x, snakey.y, SNAKE_WIDTH, SNAKE_HEIGHT, snake);
		//redraw stage
		drawBlackRectangle(snakey.x, snakey.y + 1 + SNAKE_WIDTH, 1, SNAKE_HEIGHT);

		//bat
		drawImage(batty.x, batty.y, BAT_WIDTH, BAT_HEIGHT, bat);
		//redraw stage
		drawBlackRectangle(batty.x, batty.y - 1, 1, BAT_HEIGHT);

		//score
			sprintf(buffer, "Score: %d", score);
			drawString(150, 5, buffer, YELLOW);
		}
		waitForVblank();
	}
}