//Sam Loop
//CS 2110
//HW 9

#include "myLib.h"
#include "font.h"

u16* videoBuffer = (u16*)0x6000000;

extern const unsigned short titlescreen[38400];
extern const unsigned short gameover[38400];
extern const unsigned short downdrake[1296];
extern const unsigned short normdrake[1296];
extern const unsigned short updrake[1296];
extern const unsigned short bat[144];
extern const unsigned short apple[144];
extern const unsigned short snake[144];


void waitForVblank()
{
    while(SCANLINECOUNTER > 160);
    while(SCANLINECOUNTER < 160);
}


void drawImage(int row, int col, int width, int height, const u16* image) {
    for (int i = 0; i < height; i++) {
        // Set the source
        DMA[3].src = image + i * width;
        // Set the destination
        DMA[3].dst = &videoBuffer[(row + i) * 240 + col];
        // Set our additional options in the controller (cnt)
        DMA[3].cnt = width | DMA_SOURCE_INCREMENT | DMA_DESTINATION_INCREMENT | DMA_ON;
    }
}

void drawBlackRectangle(int row, int col, int width, int height) {
    u16 black = COLOR(0, 0, 0);
    for (int i = 0; i < height; i++) {
        // Set the source
        DMA[3].src = &black;
        // Set the destination
        DMA[3].dst = &videoBuffer[(row + i) * 240 + col];
        // Set our additional options in the controller (cnt)
        DMA[3].cnt = width | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
    }
}

void drawChar(int row, int col, char ch, unsigned short color) {
    for(int r=0; r< 8; r++) {
        for(int c=0; c<6; c++) {
            if (fontdata_6x8[OFFSET(r, c, 6) + ch*48] == 1) {
                setPixel(row+r, col+c, color);
            }
        }
    }
}

void drawString(int row, int col, char str[], unsigned short color) {   
    while(*str) {
        drawChar(row, col, *str++, color);
        col += 6;
    }
}

void setPixel(int row, int col, unsigned short color) {
    videoBuffer[OFFSET(row, col, 240)] = color;
}