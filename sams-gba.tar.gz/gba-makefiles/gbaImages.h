/*
 * Exported with nin10kit v1.7
 * Time-stamp: Sunday 11/12/2017, 20:06:00
 * 
 * Image Information
 * -----------------
 * /home/samloop/Downloads/gba images/Slide1.JPG 240@160
 * /home/samloop/Downloads/gba images/Slide2.JPG 240@160
 * /home/samloop/Downloads/gba images/Slide4.JPG 60@68
 * /home/samloop/Downloads/gba images/Slide5.JPG 60@68
 * /home/samloop/Downloads/gba images/Slide6.JPG 60@68
 * /home/samloop/Downloads/gba images/Slide7.JPG 20@20
 * /home/samloop/Downloads/gba images/Slide8.JPG 45@15
 * /home/samloop/Downloads/gba images/Slide9.JPG 30@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GBAIMAGES_H
#define GBAIMAGES_H

extern const unsigned short titlescreen[38400];
#define TITLESCREEN_SIZE 76800
#define TITLESCREEN_LENGTH 38400
#define TITLESCREEN_WIDTH 240
#define TITLESCREEN_HEIGHT 160

extern const unsigned short gameover[38400];
#define GAMEOVER_SIZE 76800
#define GAMEOVER_LENGTH 38400
#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160

extern const unsigned short downdrake[4080];
#define DOWNDRAKE_SIZE 8160
#define DOWNDRAKE_LENGTH 4080
#define DOWNDRAKE_WIDTH 60
#define DOWNDRAKE_HEIGHT 68

extern const unsigned short normdrake[4080];
#define NORMDRAKE_SIZE 8160
#define NORMDRAKE_LENGTH 4080
#define NORMDRAKE_WIDTH 60
#define NORMDRAKE_HEIGHT 68

extern const unsigned short updrake[4080];
#define UPDRAKE_SIZE 8160
#define UPDRAKE_LENGTH 4080
#define UPDRAKE_WIDTH 60
#define UPDRAKE_HEIGHT 68

extern const unsigned short apple[400];
#define APPLE_SIZE 800
#define APPLE_LENGTH 400
#define APPLE_WIDTH 20
#define APPLE_HEIGHT 20

extern const unsigned short bat[675];
#define BAT_SIZE 1350
#define BAT_LENGTH 675
#define BAT_WIDTH 45
#define BAT_HEIGHT 15

extern const unsigned short snake[450];
#define SNAKE_SIZE 900
#define SNAKE_LENGTH 450
#define SNAKE_WIDTH 30
#define SNAKE_HEIGHT 15

#endif

